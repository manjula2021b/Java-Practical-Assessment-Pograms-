package PracticalAssessmentJava;

public class Program13 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int b = -3, e = 2;
	double result = Math.pow(b, e);
		System.out.println("Answer = " + result);
		}
		}


