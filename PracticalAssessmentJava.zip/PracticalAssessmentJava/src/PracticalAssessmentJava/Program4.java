package PracticalAssessmentJava;

import java.util.Scanner;

public class Program4 {
	public static void main(String[] args)
	{
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the number to check:");
		int number=input.nextInt();
		String result=(number < 100)?"Yes":"No";
		System.out.println("the number you entered is less than 100 :"+result);
		input.close();

				}
}
