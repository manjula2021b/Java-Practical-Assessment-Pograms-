package PracticalAssessmentJava;
import java.util.Scanner;
public class Program12 {

	    
	    public static void main(String[] args) {
	        
	        Scanner input = new Scanner(System.in);
	        boolean quit= false;
	        int sum=0;
	        int Coffee=20,Tea=20,WaterBottle=40,juice=100;
	        String order="";
	        
	        do{
	            System.out.println("ITEM"+"\t\tPrice");
	            System.out.println("1.Poori"+"\t\t"+"120");
	            System.out.println("2.Masal Dose"+"\t"+"50");
	            System.out.println("3.Idli and Vada"+"\t"+"75");
	            System.out.println("4.Oats"+"\t\t"+"150");
	            System.out.println("5.Quit");
	            
	            int choice=input.nextInt();
	            
	            switch(choice){
	                case 1:System.out.println("Coffee"+"\n");
	                        sum=sum+Coffee;
	                        order=order.concat("Coffee"+"\n");
	                        
	                    break;
	                case 2:
	                    System.out.println("Tea");
	                    sum=sum+Tea;
	                    order=order.concat("Tea"+"\n");
	                    
	                       break;
	                case 3:
	                    System.out.println("WaterBottle");
	                    sum=sum+WaterBottle;
	                    order=order.concat("WaterBottle"+"\n");
	                      break;
	                case 4:
	                    System.out.println("Juice");
	                    sum=sum+juice;
	                    order=order.concat("Juice"+"\n");
	                    break;
	                case 5:
	                     quit=true;
	                     
	                    break;
	                default:
	                    System.out.println("Wrong input");
	            }
	        
	        }while(!quit);
	       
	        System.out.println("Your Orders are:\n"+order);
	        System.out.println("Your total bill="+sum);
	        
	         System.out.println("Thank you");
	
	    
	    }
	    
	}


