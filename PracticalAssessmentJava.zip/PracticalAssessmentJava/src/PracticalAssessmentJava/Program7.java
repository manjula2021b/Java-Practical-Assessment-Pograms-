package PracticalAssessmentJava;


import java.util.Scanner;
public class Program7 {

		private static Scanner sc;
		public static void main(String[] args) 
		{
			int TotalMarks; 
		   
			sc = new Scanner(System.in);
			
			System.out.print(" Please Enter the Total Marks : ");
			TotalMarks = sc.nextInt();	
	
		    System.out.println(" Grade of the Student =  " );
			
			if(TotalMarks > 95 && TotalMarks <=100 )
		    {
				System.out.println("\n  A+");
			}
			else if(TotalMarks > 85)
		    {
				System.out.println("\n  A");
			}
			else if(TotalMarks > 80)
		    {
				System.out.println("\n  B+");
			}
			else if(TotalMarks > 70)
		    {
				System.out.println("\n  B");
			}
			else if(TotalMarks > 60)
		    {
				System.out.println("\n C ");
			}
			else if(TotalMarks > 50)
		    {
				System.out.println("\n D");
			}
			else if(TotalMarks < 50)
		    {
				System.out.println("\n Failed");
			}
			else if(TotalMarks > 100)
			{
				System.out.println("\n Invalid marks");
			} 
		}
	}


