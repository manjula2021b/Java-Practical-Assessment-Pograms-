package PracticalAssessmentJava;

import java.util.Scanner;
public class Program3 {
		private static Scanner sc;
		public static void main(String[] args) 
		{
			int age;
			sc = new Scanner(System.in);
			System.out.print(" Please Enter the age of a person, to determine if he/she eligible for covidshots : ");
			age = sc.nextInt();	
			if(age > 60)
		    {
				System.out.println("\n Eligible Now");
			}
			else if(age > 45)
		    {
				System.out.println("\n Eligible in 15 Days");
			}
			else if(age > 18)
		    {
				System.out.println("\n Eligible In a Month");
		    }
			else 
		    {
				System.out.println("\n Not Eligible");
			} 
		}
	}
