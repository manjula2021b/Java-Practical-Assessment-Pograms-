package PracticalAssessmentJava;

import java.util.Scanner;

public class Program16 {
	
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("enter the number:");
		int n=s.nextInt();
		if(n==1 ||n==153 ||n==370 ||n==407)
			System.out.println("Amstrong number");
		else
			System.out.println("Not Amstrong number");
	}
}
