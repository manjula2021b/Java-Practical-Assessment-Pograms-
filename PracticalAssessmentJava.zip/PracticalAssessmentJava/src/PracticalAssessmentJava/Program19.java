package PracticalAssessmentJava;

import java.util.Scanner;

public class Program19 {

	public static void main(String args[])
	{
	int n1,n2,i,min,hcf=1;
	Scanner sc = new Scanner(System.in);
	     System.out.println("Enter two integers");
	     n1=sc.nextInt();
	     n2=sc.nextInt();
	min = (n1<n2)?n1:n2;
	     for(i=1;i<=min;i++)
	     {     
	if(n1%i==0 && n2%i==0)
	         {
	             hcf = i;
	         }
	     }
	     System.out.println("HCF of "+n1+" and "+n2+" = "+hcf);
	}
	

}
