package PracticalAssessmentJava;

import java.util.Scanner;

public class Program17 {

	public static void main(String[] args)
	{
	Scanner in = new Scanner(System.in);
	System.out.print("Enter number ");
	int x = in.nextInt();
	System.out.print("factors for ");
	for(int i=1;i<=x;i++)
	{
	System.out.print(i+" is "+result(i)+",");
	}
	}
	public static int result(int num) {
	int c = 0;
	for(int i=1; i<=(int)Math.sqrt(num); i++) {
	if(num%i==0 && i*i!=num) {
	c+=2;
	} else if (i*i==num) {
	c++;
	}
	}
	return c;
	}
	}