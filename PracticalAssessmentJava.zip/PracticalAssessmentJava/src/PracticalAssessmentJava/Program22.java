package PracticalAssessmentJava;

import java.util.Scanner;

public class Program22 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,i;
		int fact,ldig;
		Scanner s=new Scanner(System.in);
		System.out.print("Enter the number:");
		n=s.nextInt();
		int total=0;
		int temp=n;
		while(n!=0)
		{
		i=1;
		fact=1;
		ldig=n%10;
		while(i<=ldig)
		{
		fact=fact*i;
		i++;
		}
		total=total+fact;
		n=n/10;
		}
		if(total==temp)
		System.out.print(temp+"is a strong number\n");
		else
		System.out.print(temp+"is not a strong number\n");
		System.out.println();
		}
		}
