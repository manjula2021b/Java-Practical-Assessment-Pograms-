package PracticalAssessmentJava;

public class Program18 {

		public static void main(String[] args) {

		int b = -3, e = 2;

		double result = Math.pow(b, e);
		System.out.println("Answer = " + result);
		}
		}


