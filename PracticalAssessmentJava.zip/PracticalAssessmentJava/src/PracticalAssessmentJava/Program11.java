package PracticalAssessmentJava;
import java.util.Scanner; 
public class Program11 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the number of hours worked");
		int h = s.nextInt();
		int salary;
		if(h>0 && h<=8) 
			salary=h*250;
		else
			salary=8*250;
		System.out.println("salary is:"+salary);
	}
}