package PracticalAssessmentJava;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Program23 {
	public static void main(String[] args) {
	Scanner input = new Scanner(System.in);
	boolean flag = false;
	System.out.println("Enter first string");
	String str1 = input.nextLine();
	System.out.println("Enter second string");
	String str2 = input.nextLine();
	for(int i = 0; i < str1.length(); i++) {
	for(int j = 0; j < str2.length(); j++) {
	if(str2.charAt(j) == str1.charAt(i)) {
	flag = true;
	break;
	}
	else {
	continue;
	}
	}
	}
	if(flag)
	System.out.println("YES");
	else
	System.out.println("NO");
	}
}


